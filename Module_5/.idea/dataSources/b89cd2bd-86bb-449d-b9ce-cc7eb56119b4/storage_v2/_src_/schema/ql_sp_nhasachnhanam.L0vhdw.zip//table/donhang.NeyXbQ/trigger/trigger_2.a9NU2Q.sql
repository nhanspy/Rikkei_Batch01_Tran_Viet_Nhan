create definer = root@localhost trigger Trigger_2
    after update
    on donhang
    for each row
BEGIN
#         UPDATE donhang SET MaDonHang = NEW.MaDonHang, MaNhanVien = NEW.MaNhanVien, NgayMuaHang = NEW.NgayMuaHang, MaKhachHang = NEW.MaKhachHang
#         WHERE NEW.NgayMuaHang <= NOW();
        IF NEW.NgayMuaHang <= NOW() THEN
            UPDATE donhang SET MaNhanVien = NEW.MaNhanVien, NgayMuaHang = NEW.NgayMuaHang, MaKhachHang = NEW.MaKhachHang
            WHERE MaDonHang = OLD.MaDonHang;
        end IF;
#         ROLLBACK ;
    end;

