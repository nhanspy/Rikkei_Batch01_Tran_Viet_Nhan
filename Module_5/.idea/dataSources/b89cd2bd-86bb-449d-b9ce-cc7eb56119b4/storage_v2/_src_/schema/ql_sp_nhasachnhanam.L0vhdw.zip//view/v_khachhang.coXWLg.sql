create definer = root@localhost view v_khachhang as
select `ql_sp_nhasachnhanam`.`khachhang`.`MaKhachHang`  AS `MaKhachHang`,
       `ql_sp_nhasachnhanam`.`khachhang`.`TenKhachHang` AS `TenKhachHang`,
       `ql_sp_nhasachnhanam`.`khachhang`.`NgaySinh`     AS `NgaySinh`,
       `ql_sp_nhasachnhanam`.`khachhang`.`SoDienThoai`  AS `SoDienThoai`
from `ql_sp_nhasachnhanam`.`khachhang`
where to_days(current_timestamp()) - to_days(`ql_sp_nhasachnhanam`.`khachhang`.`NgaySinh`) < 18;

