create
    definer = root@localhost procedure Sp_2(IN MaDonHang varchar(45))
BEGIN
    UPDATE chitietdonhang SET SoLuong = SoLuong*2 WHERE MaDonHang = MaDonHang;
end;

