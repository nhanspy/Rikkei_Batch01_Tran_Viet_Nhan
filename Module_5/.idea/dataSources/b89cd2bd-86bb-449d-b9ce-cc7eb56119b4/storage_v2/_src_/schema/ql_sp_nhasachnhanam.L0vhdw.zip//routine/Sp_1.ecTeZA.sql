create
    definer = root@localhost procedure Sp_1(IN MaDonHang varchar(45), IN MaKhachHang varchar(45),
                                            IN MaNhanVien varchar(45), IN NgayMuaHang date, IN TongTien float)
BEGIN
   INSERT INTO donhang(MaDonHang, MaKhachHang, MaNhanVien, NgayMuaHang, TongTien)
   VALUES (MaDonHang, MaKhachHang, MaNhanVien, NgayMuaHang, TongTien);
END;

